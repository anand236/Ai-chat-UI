import { Component, inject, signal } from '@angular/core';
import { AiService } from '../../core/services/ai-service';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-chat-component',
  imports: [FormsModule, ReactiveFormsModule],
  templateUrl: './chat-component.html',
  styleUrl: './chat-component.scss',
})
export class ChatComponent {

  private aiSer = inject(AiService);

  public chatData = new FormControl('');

  public chat = signal('');
  public chatResponse = signal('');

  chatHistoryData = signal<{ user: 'bot' | 'user', res: string }[]>([])

  submit() {
    if (this.chatData.value) {
      // this.chat.set(this.chatData.value);
      this.chatHistoryData().push({ user: 'user', res: this.chatData.value });
      this.aiSer.getAiResponse(this.chatData.value).subscribe({
        next: (res: any) => {
          this.chatHistoryData().push({ user: 'bot', res: res.resp })
        },
        error: (err) => {
          console.log(err);

        }
      });
      this.chatData.reset();
    }
  }

  autoResize(textarea: HTMLTextAreaElement) {
    textarea.style.height = 'auto';
    textarea.style.height = textarea.scrollHeight + 'px';
  }


  handleKeyDown(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submit();
    }
  }



}
