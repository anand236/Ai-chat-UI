import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AiService {

  private http = inject(HttpClient);

  public getAiResponse(prompt: string) {
    return this.http.get(`/api/ask-ai?prompt=${prompt}`);
  }


}
